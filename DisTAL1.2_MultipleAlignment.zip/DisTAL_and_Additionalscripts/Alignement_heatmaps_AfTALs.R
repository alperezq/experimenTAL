# Group alignements
library(gplots)
library(stringr)
library(dendextend)
library(reshape2)
library(scales)
library(readr)

TALgroups <- read_delim("~/Desktop/TAL_EV/TAL_ANALYSES/AfTALgroups.txt"," ", escape_double = FALSE, trim_ws = TRUE)

TAL_MAT<- as.matrix(read.table("/home/alvaro/Desktop/TAL_EV/TAL_ANALYSES/DistMATS/TEVMAT_TAL.mat", header=TRUE, sep = "\t",row.names = 1, as.is=TRUE))
TAL_MAT<- TAL_MAT[,1:(ncol(TAL_MAT) -1)]
colnames(TAL_MAT)<-rownames(TAL_MAT)
meltMAT<-melt(TAL_MAT)
meltMAT<-merge(meltMAT,TALgroups,by.x="Var1",by.y="TAL")
meltMAT<-merge(meltMAT,TALgroups,by.x="Var2",by.y="TAL")
colnames(meltMAT)<-c("ID1","ID2","Distance","Group2","Group1")

matname1<-as.data.frame(str_split_fixed(meltMAT$ID1, "[|]", 4)[,1:3])
meltMAT$ID1<-paste(matname1$V1,matname1$V2,matname1$V3, sep = "|")
matname2<-as.data.frame(str_split_fixed(meltMAT$ID2, "[|]", 4)[,1:3])
meltMAT$ID2<-paste(matname2$V1,matname2$V2,matname2$V3, sep = "|")

myfailed <-list()
failcount<-0

groupvec <- unique(TALgroups$Group)

for (i in 1:length(groupvec)){ 

#G<-20
G<-groupvec[i]
RVD <- read_delim(paste("~/Desktop/TAL_EV/TAL_ANALYSES/AfALIGNS/G",G,".RVDs", sep = ""),
"\t", escape_double = FALSE, col_names = FALSE,
trim_ws = TRUE)

Dist <- read_delim(paste("~/Desktop/TAL_EV/TAL_ANALYSES/AfALIGNS/G",G,".Dists", sep = ""),
"\t", escape_double = FALSE, col_names = FALSE,
trim_ws = TRUE)

mymat<-Dist
mynum<-RVD

if (nrow(mymat) > 1){

mynames<-as.data.frame(str_split_fixed(Dist$X1, "[|]", 4)[,1:3])
mynames<-paste(mynames$V1,mynames$V2,mynames$V3, sep = "|")
mymat$X1<-mynames
mynum$X1<-mynames
myfirst<- mynum$X1[1]
  
my_palette <- colorRampPalette(c("dodgerblue", "white"))(n = 100)

mySub<-meltMAT[meltMAT$ID1 %in% mynames,]
mySub<-mySub[mySub$ID2 %in% mynames,]
GroupDist <- as.matrix(acast(mySub, ID1 ~ ID2, value.var="Distance"))

mymat <- mymat[order(mymat$X1),]
mynum <- mynum[order(mynum$X1),]
GroupDist<-GroupDist[order(rownames(GroupDist)),]
GroupDist<-GroupDist[order(colnames(GroupDist)),]
Groupclus <-hclust(as.dist(GroupDist))
Groupdend<-as.dendrogram(Groupclus)


myind<-which(mymat$X1 == myfirst)
mynum <- mynum[,2:ncol(mynum)]
def <- as.matrix(100 - mymat[,2:ncol(mymat)])

clade_order <- order.dendrogram(Groupdend)
myrvcol <- mynum[clade_order,]
for (i in 1:ncol(myrvcol)){
  myval = as.character(mynum[myind,i])
  myrvcol[,i]<-ifelse(myrvcol[,i] == myval,"black","red")
}

myrvcol<-t(as.matrix(myrvcol))


possibleError <- tryCatch(a <-heatmap.2(def,Rowv = Groupdend, Colv = FALSE, dendrogram = "row",  
                                        density.info="none",trace = "none", col = my_palette,
                                        margins =c(4,12), cellnote  = mynum, notecol = myrvcol, lhei = c(1,5) ,lwid = c(0.8,4)
                                        ,labCol = c(1:ncol(mymat)), labRow = rownames(GroupDist), offsetRow = 0, key.title = NA
                                        ,key.xlab = "AA identity", main = paste("Group G",G,sep=""), xlab = "Position", ylab = "TAL ID",cexRow = 0.8
                                        ,na.color="grey"), error=function(e) e) 
if(inherits(possibleError, "error")) {failcount <- failcount+1
myfailed[[failcount]]<-G}
if(inherits(possibleError, "error")) next

svg(filename=paste("/home/alvaro/Desktop/Rstudio/TAL_EVOL/Alignments/G",G,".svg",sep=""),width = 10, height = 7.5)
a <-heatmap.2(def,Rowv = Groupdend, Colv = FALSE, dendrogram = "row",  
              density.info="none",trace = "none", col = my_palette,
              margins =c(4,12), cellnote  = mynum, notecol = myrvcol, lhei = c(1,5) ,lwid = c(0.8,4)
              ,labCol = c(1:ncol(mymat)), labRow = rownames(GroupDist), offsetRow = 0, key.title = NA
              ,key.xlab = "AA identity", main = paste("Group G",G,sep=""), xlab = "Position", ylab = "TAL ID",cexRow = 0.8
              ,na.color="grey"
)

dev.off()

}
}


####################################Heatmaps with repeat identity

library(ape)
library(readr)

#Create colo vector assigning equal hue to similar repeats

Distalmat<-as.matrix(read.table("~/Desktop/TAL_EV/TAL_ANALYSES/DistMATS/TEVMAT_Repdists.mat", header=TRUE, sep = "\t",row.names = 1, as.is=TRUE))

Distclus<-hclust(as.dist(Distalmat))
plot(Distclus)

myDistcut<-as.data.frame(cbind(Distclus$labels,cutree(Distclus, h = 5)))
colnames(myDistcut)<-c("Reps","D5")
myDistcut$D10<-cutree(Distclus, h = 10) #identity height of repeats
#myDistcut$D15<-cutree(Distclus, h = 15)
#myDistcut$D20<-cutree(Distclus, h = 20)
b<-100-Distalmat
orderRep<- order.dendrogram(as.dendrogram(Distclus))
RepID<- myDistcut$Reps
Rep_position <- data.frame(RepID,
                           orderRep)
Rep_position<-merge(Rep_position,myDistcut, by.x = "RepID", by.y = "Reps", sort = FALSE)
Rep_position<-Rep_position[order(Rep_position$orderRep),]
Rep_position$mycol <- hue_pal(l = 75)(nlevels(as.factor(Rep_position$D10)))[Rep_position$D10]

phyrep <- nj(as.matrix(as.dist(Distalmat)))
bla<-merge(phyrep$tip.label, Rep_position, by.x = "x", by.y = "RepID", sort =FALSE)
phyrep$tip.label<-as.vector(bla$D10)
phyl <- as.phylo(Distclus)
plot(phyl, type = "u", tip.color=Rep_position$mycol, show.tip.label=TRUE, cex=0.6, use.edge.length = TRUE)
plot(sort(Rep_position$orderRep), Rep_position$RepID, pch = 19, col = Rep_position$mycol)


myfailed <-list()
failcount<-0
groupvec <- unique(TALgroups$Group)

for (i in 1:length(groupvec)){ 
  
  G<-groupvec[i]
  #G<-20
  #try(dev.off())
Reps <- read_delim(paste("~/Desktop/TAL_EV/TAL_ANALYSES/AfALIGNS/G",G,".Reps", sep =""),
                   "\t", escape_double = FALSE, col_names = FALSE,
                   trim_ws = TRUE,na = "-")

Reps <- Reps[order(Reps$X1),]

mymat<-as.matrix(Reps[,2:ncol(Reps)])

if (nrow(mymat) > 1){
  
Reps[is.na(Reps)]<-"-"
mynum<-as.matrix(Reps[,2:ncol(Reps)])

mynames<-as.data.frame(str_split_fixed(Reps$X1, "[|]", 4)[,1:3])
mynames<-paste(mynames$V1,mynames$V2,mynames$V3, sep = "|")

#my_palette=rainbow(nlevels(as.factor(myDistcut$D10)))[as.integer(myDistcut$D10)]

mySub<-meltMAT[meltMAT$ID1 %in% mynames,]
mySub<-mySub[mySub$ID2 %in% mynames,]
GroupDist <- as.matrix(acast(mySub, ID1 ~ ID2, value.var="Distance"))

GroupDist<-GroupDist[order(rownames(GroupDist)),]
GroupDist<-GroupDist[order(colnames(GroupDist)),]
Groupclus <-hclust(as.dist(GroupDist))
Groupdend<-as.dendrogram(Groupclus)



possibleError <- tryCatch(a <-heatmap.2(mymat,Rowv = Groupdend, Colv = FALSE, dendrogram = "row",  
                                        density.info="none",trace = "none", col = Rep_position$mycol,
                                        margins =c(4,12), cellnote  = mynum, notecol = "black", key = FALSE,
                                        labCol = c(1:ncol(mymat)), labRow = mynames, offsetRow = 0, key.title = NA,
                                        cexRow = 0.8, main = paste("Group G",G,sep=""),
                                        na.color="grey",lhei=c(0.4,2),
                                        lwid=c(0.2,2)), error=function(e) e) 

if(inherits(possibleError, "error")) {failcount <- failcount+1
myfailed[[failcount]]<-G}
if(inherits(possibleError, "error")) {dev.off()}
if(inherits(possibleError, "error")) next


mybreaks<-seq(1,1295)
svg(filename=paste("/home/alvaro/Desktop/Rstudio/TAL_EVOL/Alignments/REPSG",G,".svg",sep=""),width = 10, height = 7.5)
a <-heatmap.2(mymat,Rowv = Groupdend, Colv = FALSE, dendrogram = "row",  
              density.info="none",trace = "none", col = Rep_position$mycol,
              margins =c(4,12), cellnote  = mynum, notecol = "black", key = FALSE,
              labCol = c(1:ncol(mymat)), labRow = mynames, offsetRow = 0, key.title = NA,
              cexRow = 0.8, main = paste("Group G",G,sep=""), breaks = mybreaks,
              na.color="grey",lhei=c(0.4,2),
              lwid=c(0.2,2))
dev.off()

}
}
